﻿param([ValidateSet('Install','Rollback')][string]$Mode = 'Install')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$exitCode = 0
try {
  $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'account-update-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  function Hash([string]$file) { return (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() }
  function AtomicCopy([string]$source, [string]$destination) {
    $source = [IO.Path]::GetFullPath($source)
    $destination = [IO.Path]::GetFullPath($destination)
    $directory = [IO.Path]::GetDirectoryName($destination)
    $id = [Guid]::NewGuid().ToString('N')
    $temp = Join-Path $directory ('rwf-' + $id + '.tmp')
    $swapBackup = Join-Path $directory ('rwf-' + $id + '.swap-backup')
    $sourceHash = Hash $source
    try {
      Copy-Item -LiteralPath $source -Destination $temp
      if ((Hash $temp) -ne $sourceHash) { throw 'Ошибка проверки скопированного файла.' }
      if (Test-Path -LiteralPath $destination -PathType Leaf) {
        # Windows PowerShell 5.1 can bind $null as an empty backup path.
        # Always supply a real absolute backup filename, never $null or an empty string.
        [IO.File]::Replace($temp, $destination, $swapBackup)
      } else {
        [IO.File]::Move($temp, $destination)
      }
      if ((Hash $destination) -ne $sourceHash) { throw 'Не совпала контрольная сумма после замены файла.' }
      if (Test-Path -LiteralPath $swapBackup) {
        try { Remove-Item -LiteralPath $swapBackup -Force -ErrorAction Stop } catch { Write-Host 'Дополнительная страховочная копия оставлена в resources.' }
      }
    } finally {
      if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
    }
  }
  $candidates = @($PSScriptRoot, (Split-Path -Parent $PSScriptRoot))
  $roots = @($candidates | Where-Object {
    (Test-Path -LiteralPath (Join-Path $_ 'resources\app.asar') -PathType Leaf) -or
    (Test-Path -LiteralPath (Join-Path $_ 'resources\rumblewersfad-account-update.json') -PathType Leaf)
  } | Select-Object -Unique)
  if ($roots.Count -ne 1) { throw 'Не найдена папка лаунчера. Помести папку обновления рядом с EXE лаунчера. Папку Game выбирать не нужно.' }
  $root = [IO.Path]::GetFullPath($roots[0]).TrimEnd('\')
  $resources = Join-Path $root 'resources'
  $target = Join-Path $resources 'app.asar'
  $marker = Join-Path $resources 'rumblewersfad-account-update.json'
  $running = @(Get-CimInstance Win32_Process | Where-Object {
    $_.ExecutablePath -and ([string]$_.ExecutablePath).StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase) -and ([string]$_.Name).EndsWith('.exe', [StringComparison]::OrdinalIgnoreCase)
  })
  if ($running.Count -gt 0) { throw 'Полностью закрой игру и лаунчер, включая значок в трее. Файлы приложения не заменялись.' }
  $record = $null
  $backup = $null
  if (Test-Path -LiteralPath $marker -PathType Leaf) {
    $record = Get-Content -LiteralPath $marker -Raw -Encoding UTF8 | ConvertFrom-Json
    $name = [string]$record.backupName
    if ([string]::IsNullOrWhiteSpace($name) -or $name -ne [IO.Path]::GetFileName($name) -or $name -notmatch '^app\.asar\.before-account-[A-Za-z0-9-]+\.bak$') { throw 'Запись восстановления повреждена. Ничего не заменено; резервные копии сохранены.' }
    if ($record.baselineSha256 -ne $manifest.baselineSha256 -or $record.updateSha256 -ne $manifest.updateSha256) { throw 'Запись относится к другому обновлению. Автоматическая замена отменена.' }
    $backup = Join-Path $resources $name
    if (!(Test-Path -LiteralPath $backup -PathType Leaf) -or (Hash $backup) -ne $manifest.baselineSha256) { throw 'Резервная копия из предыдущей попытки не прошла проверку. Ничего не заменено.' }
  }
  $currentHash = ''
  if (Test-Path -LiteralPath $target -PathType Leaf) { $currentHash = Hash $target }
  if ($Mode -eq 'Install') {
    $payload = Join-Path $PSScriptRoot 'payload\app.asar'
    if ((Hash $payload) -ne $manifest.updateSha256) { throw 'Файл обновления повреждён. Установка отменена.' }
    if ($currentHash -eq $manifest.updateSha256) {
      Write-Host 'Обновление уже установлено; повторная замена не нужна.'
      if (!$record) { Write-Host 'Запись отката не найдена. Существующие резервные копии не удаляй.' }
    } else {
      if ($currentHash -ne $manifest.baselineSha256 -and !($currentHash -eq '' -and $record)) {
        throw 'Текущий app.asar отличается от присланной версии 1.2.0. Замена отменена, чтобы не затереть другую сборку.'
      }
      if (!$record) {
        $backupName = 'app.asar.before-account-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N') + '.bak'
        $backup = Join-Path $resources $backupName
        Copy-Item -LiteralPath $target -Destination $backup
        if ((Hash $backup) -ne $manifest.baselineSha256) { throw 'Не удалось проверить резервную копию. Установка отменена.' }
        $record = @{ version = $manifest.version; backupName = $backupName; baselineSha256 = $manifest.baselineSha256; updateSha256 = $manifest.updateSha256 }
        $record | ConvertTo-Json | Set-Content -LiteralPath $marker -Encoding UTF8
      } else {
        Write-Host 'Найдена незавершённая попытка. Резервная копия проверена, установка будет продолжена.'
      }
      try {
        AtomicCopy $payload $target
        if ((Hash $target) -ne $manifest.updateSha256) { throw 'Проверка установленного обновления не пройдена.' }
      } catch {
        $installError = $_.Exception.Message
        $needsRestore = $true
        if (Test-Path -LiteralPath $target -PathType Leaf) { $needsRestore = (Hash $target) -ne $manifest.baselineSha256 }
        if ($needsRestore) {
          try { AtomicCopy $backup $target }
          catch { throw ('Ошибка установки: ' + $installError + ' Автовосстановление не завершено. Резервная копия и запись восстановления сохранены; ничего не удаляй.') }
        }
        if ((Hash $target) -ne $manifest.baselineSha256) { throw 'Не удалось подтвердить восстановленную исходную версию. Резервная копия сохранена.' }
        throw ('Обновление не установлено. Исходный app.asar сохранён или восстановлен. Повторный запуск разрешён. Причина: ' + $installError)
      }
      Write-Host ('Обновление ' + $manifest.version + ' установлено.')
    }
    Write-Host 'Game, настройки и ключи исходного rVclient установщик не меняет.'
    Write-Host 'Запусти обычный EXE лаунчера и нажми Играть. Ник пока оставь Идиот.'
    Write-Host 'Если сохранённый вход не найден, другой аккаунт автоматически выбираться не будет.'
    Write-Host 'Для возврата прежнего лаунчера используй Откатить.cmd.'
  } else {
    if (!$record) { throw 'Запись восстановления не найдена. Автоматический откат не выполнялся.' }
    if ($currentHash -ne '' -and $currentHash -ne $record.updateSha256 -and $currentHash -ne $record.baselineSha256) { throw 'После обновления app.asar изменился. Откат отменён, чтобы не затереть другую сборку.' }
    if ($currentHash -ne $record.baselineSha256) { AtomicCopy $backup $target }
    if ((Hash $target) -ne $record.baselineSha256) { throw 'Не удалось подтвердить восстановленную версию.' }
    Remove-Item -LiteralPath $marker -Force
    Write-Host 'Прежний лаунчер восстановлен. Game и настройки не менялись.'
    Write-Host 'Откат кода не отменяет переименование, которое ты сам подтвердил на сервере.'
  }
} catch {
  Write-Host ''
  Write-Host ('ОШИБКА: ' + $_.Exception.Message) -ForegroundColor Red
  $exitCode = 1
}
exit $exitCode
