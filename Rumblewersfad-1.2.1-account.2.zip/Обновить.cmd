@echo off
setlocal
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Update.ps1" -Mode Install
set "RESULT=%ERRORLEVEL%"
echo.
pause
exit /b %RESULT%
