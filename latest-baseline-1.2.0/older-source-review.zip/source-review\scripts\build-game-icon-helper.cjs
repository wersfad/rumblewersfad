'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
if (process.platform !== 'win32') {
  console.error('The game icon helper must be built on Windows. Use the same Windows build as before.');
  process.exit(1);
}
const windir = process.env.WINDIR || process.env.SystemRoot || 'C:\Windows';
const compilers = ['Framework64', 'Framework'].map((name) =>
  path.join(windir, 'Microsoft.NET', name, 'v4.0.30319', 'csc.exe'));
const compiler = compilers.find((file) => fs.existsSync(file));
if (!compiler) {
  console.error('Windows .NET Framework C# compiler was not found. Do not download an unknown compiler. Send this error for review.');
  process.exit(1);
}
const source = path.join(root, 'tools', 'GameWindowIcon.cs');
const output = path.join(root, 'assets', 'game-window-icon.exe');
fs.mkdirSync(path.dirname(output), { recursive: true });
const result = spawnSync(compiler, ['/nologo', '/target:winexe', '/platform:x64', '/optimize+',
  '/out:' + output, source], { stdio: 'inherit', windowsHide: true, timeout: 60_000 });
if (result.error || result.status !== 0 || !fs.existsSync(output)) {
  console.error('Game icon helper compilation failed: ' + (result.error?.message || result.status));
  process.exit(1);
}
console.log('Game icon helper built.');
