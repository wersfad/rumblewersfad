import fs from 'node:fs/promises';
import path from 'node:path';

// Only metadata is cached. File contents never accumulate in launcher memory.
const MAX_FILE_BYTES = 128 * 1024;
const MAX_PASS_BYTES = 512 * 1024;
const MAX_FILES = 16;
const OVERLAP_BYTES = 512;
type Stamp = { size: number; mtimeMs: number; ctimeMs: number; ino: number };
export interface LogTail { file: string; text: string }
const stamps = new Map<string, Stamp>();
let rootsKey = '';
let cacheGeneration = 0;

export function resetBackgroundLogCache(): void {
  cacheGeneration++;
  stamps.clear();
  rootsKey = '';
}

/** Async, bounded log reads: unchanged files are not read again. */
export async function readChangedLogTails(roots: string[]): Promise<LogTail[]> {
  const key = JSON.stringify(roots);
  if (rootsKey !== key) { cacheGeneration++; stamps.clear(); rootsKey = key; }
  const generation = cacheGeneration;
  const candidates: { file: string; stamp: Stamp }[] = [];
  for (const root of roots) {
    // opendir avoids materializing a whole large directory synchronously.
    try {
      const dir = await fs.opendir(root);
      for await (const entry of dir) {
        if (!entry.isFile() || !/\.(log|txt|json|ini)$/i.test(entry.name)) continue;
        const file = path.join(root, entry.name);
        try {
          const stat = await fs.stat(file);
          if (!stat.isFile()) continue;
          candidates.push({ file, stamp: {
            size: stat.size, mtimeMs: stat.mtimeMs, ctimeMs: stat.ctimeMs, ino: stat.ino
          } });
          candidates.sort((a, b) => b.stamp.mtimeMs - a.stamp.mtimeMs || a.file.localeCompare(b.file));
          if (candidates.length > MAX_FILES) candidates.pop();
        } catch { /* Rotated/deleted or inaccessible file. */ }
      }
    } catch { /* This game build may not have this directory. */ }
  }
  if (rootsKey !== key || generation !== cacheGeneration) return []; // Settings changed during the scan.
  const selected = new Set(candidates.map((c) => c.file));
  for (const file of stamps.keys()) if (!selected.has(file)) stamps.delete(file);
  const result: LogTail[] = [];
  let budget = MAX_PASS_BYTES;
  for (const { file, stamp } of candidates) {
    if (rootsKey !== key || generation !== cacheGeneration || budget <= 0) break;
    const previous = stamps.get(file);
    if (previous && previous.size === stamp.size && previous.mtimeMs === stamp.mtimeMs
        && previous.ctimeMs === stamp.ctimeMs && previous.ino === stamp.ino) continue;
    // Initial/rotated/truncated files: recent tail. Growing files: new bytes + overlap.
    const appended = previous && stamp.ino === previous.ino && stamp.size > previous.size;
    const start = Math.max(0, stamp.size - Math.min(MAX_FILE_BYTES, budget),
      appended ? previous.size - OVERLAP_BYTES : 0);
    let handle: Awaited<ReturnType<typeof fs.open>> | undefined;
    try {
      handle = await fs.open(file, 'r');
      const before = await handle.stat();
      if (!before.isFile() || before.ino !== stamp.ino || before.size < stamp.size
          || before.mtimeMs !== stamp.mtimeMs || before.ctimeMs !== stamp.ctimeMs) continue;
      const buffer = Buffer.alloc(stamp.size - start);
      let bytesRead = 0;
      while (bytesRead < buffer.length) {
        const read = await handle.read(buffer, bytesRead, buffer.length - bytesRead, start + bytesRead);
        if (!read.bytesRead) break;
        bytesRead += read.bytesRead;
      }
      budget -= bytesRead;
      const after = await handle.stat();
      // Do not cache a file that was rewritten while being read.
      if (after.size !== stamp.size || after.mtimeMs !== stamp.mtimeMs || after.ctimeMs !== stamp.ctimeMs) continue;
      if (rootsKey !== key || generation !== cacheGeneration) break;
      stamps.set(file, stamp);
      if (bytesRead) result.push({ file, text: buffer.subarray(0, bytesRead).toString('utf8') });
    } catch { /* Log writers may rotate or lock files temporarily on Windows. */ }
    finally { await handle?.close().catch(() => {}); }
  }
  return result;
}
