import { app } from 'electron';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { log } from './logs.js';

/** Taskbar-specific v2. Optional cosmetic action; failures must never stop game launch. */
export function applyLauncherIcon(pid: number, gameFolder: string): void {
  if (process.platform !== 'win32' || !Number.isSafeInteger(pid) || pid <= 0) return;
  try {
    const resources = app.isPackaged ? process.resourcesPath : path.join(app.getAppPath(), 'assets');
    const helperPath = path.join(resources, 'game-window-icon.exe');
    const iconPath = path.join(resources, app.isPackaged ? 'game-window-icon.ico' : 'icon.ico');
    if (!fs.existsSync(helperPath) || !fs.existsSync(iconPath)) {
      log('game icon helper/resources missing; launch unchanged', 'warn');
      return;
    }
    const helper = spawn(helperPath, [String(pid), iconPath, path.resolve(gameFolder),
      path.join(app.getPath('desktop'), 'Rumblewersfad-icon-report-v2.txt'), process.execPath], {
      shell: false, detached: true, windowsHide: true, stdio: 'ignore'
    });
    helper.once('error', (error) => log('game icon helper failed: ' + error.message, 'warn'));
    helper.unref();
  } catch (error: unknown) {
    log('game icon helper skipped: ' + String(error), 'warn');
  }
}
