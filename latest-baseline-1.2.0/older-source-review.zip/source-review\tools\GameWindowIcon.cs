using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

// No injection, executable/resource edits, privilege changes or process priority changes.
// Bounded startup discovery, then a kernel wait to keep HICON handles alive.
internal static class GameWindowIcon
{
    const uint QUERY = 0x1000, SYNCHRONIZE = 0x100000, STILL_ACTIVE = 259;
    const uint TH32CS_SNAPPROCESS = 2, WM_SETICON = 0x80;
    const uint SMTO_ABORTIFHUNG = 2, SMTO_BLOCK = 1, LOAD_FROM_FILE = 0x10;
    static readonly Dictionary<uint, IntPtr> Processes = new Dictionary<uint, IntPtr>();
    static readonly HashSet<IntPtr> Changed = new HashSet<IntPtr>();
    static string Folder, LogFile, LauncherExe;
    static IntPtr Big, Small;
    static int Failures;
    delegate bool EnumWindowProc(IntPtr window, IntPtr parameter);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct PROCESSENTRY32 {
        public uint dwSize, cntUsage, th32ProcessID;
        public UIntPtr th32DefaultHeapID;
        public uint th32ModuleID, cntThreads, th32ParentProcessID;
        public int pcPriClassBase;
        public uint dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szExeFile;
    }
    [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
    [DllImport("kernel32.dll", SetLastError = true)] static extern bool CloseHandle(IntPtr handle);
    [DllImport("kernel32.dll")] static extern bool GetExitCodeProcess(IntPtr process, out uint code);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern bool QueryFullProcessImageName(IntPtr process, uint flags, StringBuilder path, ref uint length);
    [DllImport("kernel32.dll", SetLastError = true)] static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint pid);
    [DllImport("kernel32.dll", EntryPoint = "Process32FirstW", CharSet = CharSet.Unicode)] static extern bool Process32First(IntPtr snapshot, ref PROCESSENTRY32 entry);
    [DllImport("kernel32.dll", EntryPoint = "Process32NextW", CharSet = CharSet.Unicode)] static extern bool Process32Next(IntPtr snapshot, ref PROCESSENTRY32 entry);
    [DllImport("kernel32.dll", SetLastError = true)] static extern uint WaitForMultipleObjects(uint count, IntPtr[] handles, bool all, uint milliseconds);
    [DllImport("user32.dll")] static extern bool EnumWindows(EnumWindowProc callback, IntPtr parameter);
    [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
    [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr window, uint command);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr window, StringBuilder text, int count);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr window, StringBuilder text, int count);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern IntPtr LoadImage(IntPtr instance, string name, uint type, int cx, int cy, uint flags);
    [DllImport("user32.dll", SetLastError = true)] static extern bool DestroyIcon(IntPtr icon);
    [DllImport("user32.dll", EntryPoint = "SendMessageTimeoutW", SetLastError = true)] static extern IntPtr SendMessageTimeout(IntPtr window, uint message, UIntPtr wparam, IntPtr lparam, uint flags, uint timeout, out UIntPtr result);


    [StructLayout(LayoutKind.Sequential)]
    struct PROPERTYKEY {
        public Guid format;
        public uint id;
        public PROPERTYKEY(uint value) { format = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"); id = value; }
    }
    // x64 helper: PROPVARIANT is 24 bytes, pointer union starts at byte 8.
    [StructLayout(LayoutKind.Explicit, Size = 24)]
    struct PROPVARIANT {
        [FieldOffset(0)] public ushort type;
        [FieldOffset(8)] public IntPtr pointer;
    }
    [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IPropertyStore {
        [PreserveSig] int GetCount(out uint count);
        [PreserveSig] int GetAt(uint index, out PROPERTYKEY key);
        [PreserveSig] int GetValue(ref PROPERTYKEY key, out PROPVARIANT value);
        [PreserveSig] int SetValue(ref PROPERTYKEY key, ref PROPVARIANT value);
        [PreserveSig] int Commit();
    }
    [DllImport("shell32.dll", PreserveSig = true)]
    static extern int SHGetPropertyStoreForWindow(IntPtr window, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out IPropertyStore store);
    [DllImport("ole32.dll", PreserveSig = true)] static extern int PropVariantClear(ref PROPVARIANT value);

    static void SetString(IPropertyStore store, uint id, string text) {
        var key = new PROPERTYKEY(id);
        var value = new PROPVARIANT(); value.type = 31; // VT_LPWSTR
        value.pointer = Marshal.StringToCoTaskMemUni(text);
        try { Marshal.ThrowExceptionForHR(store.SetValue(ref key, ref value)); }
        finally { Marshal.FreeCoTaskMem(value.pointer); }
    }
    static bool SetTaskbarProperties(IntPtr window) {
        IPropertyStore store = null;
        uint[] ids = { 2, 3, 4, 5 }; // RelaunchCommand, IconResource, DisplayName, ID.
        var original = new PROPVARIANT[4]; int captured = 0; int written = 0;
        bool success = false;
        try {
            Guid iid = typeof(IPropertyStore).GUID;
            int hr = SHGetPropertyStoreForWindow(window, ref iid, out store);
            Marshal.ThrowExceptionForHR(hr);
            if (store == null) throw new InvalidOperationException("No window property store");
            for (int i = 0; i < ids.Length; i++) {
                var key = new PROPERTYKEY(ids[i]);
                Marshal.ThrowExceptionForHR(store.GetValue(ref key, out original[i])); captured++;
            }
            // Set relaunch metadata first and AppID last, as required by the Shell API.
            // A pinned game button opens the launcher, never bypasses nickname/auth preparation.
            string[] values = { "\"" + LauncherExe + "\"", Path.GetFullPath(IconPath) + ",0",
                "Rumbleverse", "com.rumblewersfad.game.IconV2" };
            for (int i = 0; i < ids.Length; i++) { SetString(store, ids[i], values[i]); written++; }
            var idKey = new PROPERTYKEY(5); PROPVARIANT verify;
            Marshal.ThrowExceptionForHR(store.GetValue(ref idKey, out verify));
            try {
                if (verify.type != 31 || Marshal.PtrToStringUni(verify.pointer) != values[3])
                    throw new InvalidOperationException("AppID readback did not match");
            } finally { PropVariantClear(ref verify); }
            success = true;
            WriteLog("Taskbar properties accepted and AppID readback matched.");
            return true;
        } catch (Exception error) {
            WriteLog("Taskbar properties failed; HRESULT=0x" + error.HResult.ToString("X8") + "; " + error.Message);
            return false;
        } finally {
            // Roll back partial writes. Never leave a half-configured identity on failure.
            if (!success && store != null) for (int i = written - 1; i >= 0; i--) {
                var key = new PROPERTYKEY(ids[i]);
                try { store.SetValue(ref key, ref original[i]); } catch { }
            }
            for (int i = 0; i < captured; i++) PropVariantClear(ref original[i]);
            if (store != null) Marshal.ReleaseComObject(store);
        }
    }
    static string IconPath;

    static void WriteLog(string message) {
        try { File.AppendAllText(LogFile, DateTime.Now.ToString("s") + " " + message + Environment.NewLine); } catch { }
    }
    static bool Alive(IntPtr handle) {
        uint code;
        return GetExitCodeProcess(handle, out code) && code == STILL_ACTIVE;
    }
    static void Track(uint pid) {
        if (pid == 0 || Processes.ContainsKey(pid) || Processes.Count >= 16) return;
        IntPtr handle = OpenProcess(QUERY | SYNCHRONIZE, false, pid);
        if (handle == IntPtr.Zero) return;
        var buffer = new StringBuilder(32768); uint length = (uint)buffer.Capacity;
        bool ok = QueryFullProcessImageName(handle, 0, buffer, ref length);
        string executable = ok ? Path.GetFullPath(buffer.ToString()) : "";
        if (!ok || !executable.StartsWith(Folder, StringComparison.OrdinalIgnoreCase)) {
            CloseHandle(handle); return;
        }
        Processes.Add(pid, handle);
    }
    static void Discover(uint root) {
        IntPtr snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot == IntPtr.Zero || snapshot == new IntPtr(-1)) return;
        var parents = new Dictionary<uint, uint>();
        try {
            var entry = new PROCESSENTRY32(); entry.dwSize = (uint)Marshal.SizeOf(typeof(PROCESSENTRY32));
            if (Process32First(snapshot, ref entry)) do { parents[entry.th32ProcessID] = entry.th32ParentProcessID; }
                while (Process32Next(snapshot, ref entry));
        } finally { CloseHandle(snapshot); }
        // Only descendants of the process launched by this launcher, within its game folder.
        for (int depth = 0; depth < 6; depth++) {
            int before = Processes.Count;
            foreach (var pair in parents) {
                if (Processes.ContainsKey(pair.Key)) continue;
                if (pair.Value == root || Processes.ContainsKey(pair.Value)) Track(pair.Key);
            }
            if (before == Processes.Count) break;
        }
    }
    static bool SetIcons(IntPtr window, IntPtr parameter) {
        if (Changed.Count >= 32 || Changed.Contains(window) || !IsWindowVisible(window)) return true;
        uint pid; GetWindowThreadProcessId(window, out pid);
        IntPtr process;
        if (!Processes.TryGetValue(pid, out process) || !Alive(process)) return true;
        if (GetWindow(window, 4) != IntPtr.Zero) return true; // GW_OWNER: skip owned dialogs.
        var title = new StringBuilder(256); var kind = new StringBuilder(256);
        GetWindowText(window, title, title.Capacity); GetClassName(window, kind, kind.Capacity);
        if (kind.ToString().IndexOf("Unreal", StringComparison.OrdinalIgnoreCase) < 0
            && title.ToString().IndexOf("Rumbleverse", StringComparison.OrdinalIgnoreCase) < 0) return true;
        WriteLog("Candidate PID=" + pid + "; class=" + kind.ToString() + "; title=" + title.ToString());
        bool taskbar = SetTaskbarProperties(window);
        UIntPtr result;
        IntPtr a = SendMessageTimeout(window, WM_SETICON, new UIntPtr(1), Big, SMTO_ABORTIFHUNG | SMTO_BLOCK, 150, out result);
        IntPtr b = SendMessageTimeout(window, WM_SETICON, UIntPtr.Zero, Small, SMTO_ABORTIFHUNG | SMTO_BLOCK, 150, out result);
        // Attempt once per HWND, even if denied. Never retry forever or bypass UIPI.
        Changed.Add(window);
        if (!taskbar || a == IntPtr.Zero || b == IntPtr.Zero) {
            Failures++; WriteLog("At least one icon operation failed; see taskbar HRESULT above. Last Win32=" + Marshal.GetLastWin32Error());
        } else WriteLog("Window and taskbar properties accepted; PID=" + pid + ". Verify actual taskbar visually.");
        return true;
    }
    [STAThread]
    static int Main(string[] args) {
        if (args.Length != 5) return 2;
        uint root;
        if (!UInt32.TryParse(args[0], out root) || root == 0) return 2;
        try {
            Folder = Path.GetFullPath(args[2]).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            LogFile = args[3];
            LauncherExe = Path.GetFullPath(args[4]);
            try { File.WriteAllText(LogFile, "Game taskbar icon helper v2 started" + Environment.NewLine); } catch { }
            IconPath = Path.GetFullPath(args[1]);
            // ICO is copied from the launcher's assets, not extracted from Electron.exe.
            Big = LoadImage(IntPtr.Zero, args[1], 1, 32, 32, LOAD_FROM_FILE);
            Small = LoadImage(IntPtr.Zero, args[1], 1, 16, 16, LOAD_FROM_FILE);
            if (Big == IntPtr.Zero || Small == IntPtr.Zero) { WriteLog("Cannot load launcher ICO."); return 3; }
            WriteLog("Version=2; startup limit=45s; root PID=" + root);
            Track(root);
            var watch = Stopwatch.StartNew();
            while (watch.ElapsedMilliseconds < 45000) {
                Discover(root);
                EnumWindows(SetIcons, IntPtr.Zero);
                Thread.Sleep(1000);
            }
            WriteLog("Startup discovery finished. Windows=" + Changed.Count + ", failures=" + Failures);
            // Window icons must remain valid: retain HICON handles until tracked game processes exit.
            // This blocks in the kernel: no WMI, CPU polling, file scanning or PowerShell process.
            if (Changed.Count > 0 && Processes.Count > 0) {
                var handles = new IntPtr[Processes.Count]; Processes.Values.CopyTo(handles, 0);
                WaitForMultipleObjects((uint)handles.Length, handles, true, UInt32.MaxValue);
            }
            return Changed.Count == 0 ? 4 : (Failures > 0 ? 5 : 0);
        } catch (Exception error) { WriteLog(error.Message); return 6; }
        finally {
            foreach (IntPtr handle in Processes.Values) CloseHandle(handle);
            if (Big != IntPtr.Zero) DestroyIcon(Big);
            if (Small != IntPtr.Zero) DestroyIcon(Small);
        }
    }
}
